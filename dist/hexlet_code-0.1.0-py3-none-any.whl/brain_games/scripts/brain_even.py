from brain_games.games_logic.brain_even_logic import brain_even


def main():
    brain_even()


if __name__ == '__main__':
    main()
